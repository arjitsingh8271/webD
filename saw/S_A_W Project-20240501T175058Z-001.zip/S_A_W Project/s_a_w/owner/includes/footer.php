<div class="footer">
			<div class="wthree-copyright">
			  <p>© Design & Developed by BCREC-APC BCA 2020-23 All rights reserved.</p>
			</div>
		  </div>
