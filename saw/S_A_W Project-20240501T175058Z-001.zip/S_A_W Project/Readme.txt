STUDENT ACCOMMODATION WEBSITE

the student who gets admission in college our website provides rooms for a student as well as we provide services like a mess (food), books (old). website having student login, owner login, admin panel.



1. install xampp server software
2. copy s_a_w folder and past in win:	c/xampp/htdocs
				linux:	/opt/lampp/htdocs
3. open xampp server and start MySQL & Apache
4. localhost/phpmyadmin		open in web browser
5. import s_a_w_db
6. localhost/s_a_w		open in web browser
